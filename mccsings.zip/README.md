# Masterworks Concert Chorale site

[github.com/plr108](https://github.com/plr108)

[patrick.l.roche@gmail.com](mailto:patrick.l.roche@gmail.com)

###Project Overview

This repository contains the Masterworks Concert Chorale site.  The site is for a non-profit concert chorale in Murrysville, PA.  The site is hosted on the web at http://www.mccsings.com